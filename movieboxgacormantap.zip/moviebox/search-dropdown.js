// ============================================
// SEARCH DROPDOWN - dipakai di topbar semua halaman
// Menampilkan quick results saat mengetik, Enter
// mengarahkan ke search.html?q=keyword
// ============================================

function initTopbarSearch() {
  const searchBox = document.querySelector(".search-box");
  if (!searchBox) return;

  const input = searchBox.querySelector("input");
  let dropdown = document.querySelector(".search-dropdown");

  if (!dropdown) {
    dropdown = document.createElement("div");
    dropdown.className = "search-dropdown";
    searchBox.parentElement.style.position = "relative";
    searchBox.parentElement.appendChild(dropdown);
  }

  function closeDropdown() {
    dropdown.classList.remove("active");
    dropdown.innerHTML = "";
  }

  function renderResults(keyword) {
    const movies = Store.getAllMovies();
    const filtered = movies.filter((m) =>
      m.title.toLowerCase().includes(keyword.toLowerCase())
    );

    if (!keyword.trim()) {
      closeDropdown();
      return;
    }

    if (filtered.length === 0) {
      dropdown.innerHTML = `<div class="search-dropdown-empty">Tidak ada film ditemukan untuk "${keyword}"</div>`;
      dropdown.classList.add("active");
      return;
    }

    dropdown.innerHTML = `
      <div class="search-dropdown-label">Quick Results</div>
      ${filtered
        .slice(0, 5)
        .map(
          (m) => `
        <a class="search-dropdown-item" href="detail.html?id=${m.id}">
          <span class="search-dropdown-thumb" style="background-image:${m.poster};"></span>
          <span>
            <span class="search-dropdown-title">${m.title}</span>
            <span class="search-dropdown-sub">${m.director} • ${m.year}</span>
          </span>
        </a>
      `
        )
        .join("")}
    `;
    dropdown.classList.add("active");
  }

  input.addEventListener("input", (e) => {
    renderResults(e.target.value);
  });

  input.addEventListener("keydown", (e) => {
    if (e.key === "Enter" && input.value.trim()) {
      window.location.href = `search.html?q=${encodeURIComponent(input.value.trim())}`;
    }
  });

  document.addEventListener("click", (e) => {
    if (!searchBox.parentElement.contains(e.target)) {
      closeDropdown();
    }
  });
}

document.addEventListener("DOMContentLoaded", initTopbarSearch);
