// ============================================
// DETAIL FILM - render 1 film berdasarkan ?id=
// + Mark as Watched, Edit, Remove (dengan konfirmasi)
// ============================================

const params = new URLSearchParams(window.location.search);
const movieId = params.get('id');

const detailContent = document.getElementById('detailContent');
const deleteModal = document.getElementById('deleteModal');
const deleteMovieTitle = document.getElementById('deleteMovieTitle');
const confirmDeleteBtn = document.getElementById('confirmDeleteBtn');

function formatDate(dateStr) {
  if (!dateStr) return '-';
  const d = new Date(dateStr);
  if (isNaN(d)) return dateStr;
  return d.toLocaleDateString('en-US', { year: 'numeric', month: 'short', day: 'numeric' }).toUpperCase();
}

function render() {
  const movie = Store.getMovieById(movieId);

  if (!movie) {
    detailContent.innerHTML = `<p class="empty-state">Film tidak ditemukan. <a href="home.html" style="color:#e8877e;">Kembali ke Home</a></p>`;
    return;
  }

  const isWatched = movie.status === 'watched';

  detailContent.innerHTML = `
    <div class="detail-poster" style="background-image:${movie.poster};"></div>
    <div class="detail-info">
      <div class="badge-row">
        <span class="badge">${movie.year}</span>
        <span class="badge">${movie.genre}</span>
      </div>
      <h2 class="detail-title">${movie.title.toUpperCase()}</h2>
      <div class="detail-subrow">
        <span>
          <svg viewBox="0 0 24 24"><path d="M7 2v2H5c-1.1 0-2 .9-2 2v13c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2V6c0-1.1-.9-2-2-2h-2V2h-2v2H9V2H7zM5 9h14v10H5V9z"/></svg>
          Directed by ${movie.director}
        </span>
        <span>
          <svg viewBox="0 0 24 24"><path d="M12 2a10 10 0 1 0 0 20 10 10 0 0 0 0-20zm1 10.6l4.2 2.5-.8 1.3L11 13V6h1.5v6.6z"/></svg>
          ${movie.duration}
        </span>
      </div>

      <div class="synopsis-box">
        <h3>Synopsis</h3>
        <p>${movie.synopsis}</p>
      </div>

      <div class="action-row">
        <button class="btn-primary-pill ${isWatched ? 'watched' : ''}" id="toggleWatchedBtn">
          <svg viewBox="0 0 24 24"><path d="M8 5v14l11-7z"/></svg>
          ${isWatched ? 'Watched' : 'Mark as Watched'}
        </button>
        <a class="btn-dark-pill" href="editmovie.html?id=${movie.id}">
          <svg viewBox="0 0 24 24"><path d="M3 17.25V21h3.75L17.81 9.94l-3.75-3.75L3 17.25zM20.71 7.04c.39-.39.39-1.02 0-1.41l-2.34-2.34a1 1 0 0 0-1.41 0l-1.83 1.83 3.75 3.75 1.83-1.83z"/></svg>
          Edit Details
        </a>
      </div>

      <button class="btn-danger-outline" id="openDeleteBtn" style="margin-bottom:30px;">
        <svg viewBox="0 0 24 24"><path d="M6 7h12l-1 13H7L6 7zm3-4h6l1 2h4v2H4V5h4l1-2z"/></svg>
        Remove
      </button>

      <div class="detail-footer">
        <div class="label">Added to list</div>
        <div class="value">${formatDate(movie.addedDate)}</div>
      </div>
    </div>
  `;

  document.getElementById('toggleWatchedBtn').addEventListener('click', () => {
    const newStatus = isWatched ? 'want' : 'watched';
    Store.updateMovie(movie.id, { status: newStatus });
    render();
  });

  document.getElementById('openDeleteBtn').addEventListener('click', () => {
    deleteMovieTitle.textContent = `"${movie.title}"`;
    deleteModal.classList.add('active');
  });
}

render();

// Modal hapus
document.querySelectorAll('[data-close-delete]').forEach((btn) => {
  btn.addEventListener('click', () => deleteModal.classList.remove('active'));
});

deleteModal.addEventListener('click', (e) => {
  if (e.target === deleteModal) deleteModal.classList.remove('active');
});

confirmDeleteBtn.addEventListener('click', () => {
  Store.removeMovie(movieId);
  window.location.href = 'home.html';
});
