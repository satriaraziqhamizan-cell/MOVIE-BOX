// ============================================
// PROFILE — render info profil + daftar review
// + modal Edit Profile & Log a New Film
// ============================================

const reviewGrid = document.getElementById('reviewGrid');
const profileUsernameEl = document.getElementById('profileUsername');
const statReviews = document.getElementById('statReviews');
const statFollowers = document.getElementById('statFollowers');
const statFollowing = document.getElementById('statFollowing');

function renderProfile() {
  const profile = Store.getProfile();
  profileUsernameEl.textContent = `@${profile.username}`;
  statFollowers.textContent = profile.followers;
  statFollowing.textContent = profile.following;
}

function renderReviews() {
  const reviews = Store.getAllReviews();
  statReviews.textContent = reviews.length;

  reviewGrid.innerHTML = '';

  reviews.forEach((review) => {
    const card = document.createElement('div');
    card.className = 'review-card';
    card.innerHTML = `
      <div class="review-poster" style="background-image:${review.poster};">
        <div class="review-title-row">
          <span>${review.movieTitle}</span>
          <span class="review-rating">★${review.rating.toFixed(1)}</span>
        </div>
      </div>
      <div class="review-body">
        <p>${review.text}</p>
        <div class="review-footer">
          <span class="like-pill">+${review.likes}</span>
          <span>${review.timeAgo}</span>
        </div>
      </div>
    `;
    reviewGrid.appendChild(card);
  });

  // Kartu "Log a New Film" selalu di akhir
  const addCard = document.createElement('div');
  addCard.className = 'review-card add-new';
  addCard.id = 'logNewFilmCard';
  addCard.innerHTML = `
    <div class="plus-circle">
      <svg viewBox="0 0 24 24"><path d="M19 13h-6v6h-2v-6H5v-2h6V5h2v6h6v2z"/></svg>
    </div>
    <strong>Log a New Film</strong>
    <span>Rate and review your latest watch.</span>
  `;
  reviewGrid.appendChild(addCard);

  document.getElementById('logNewFilmCard').addEventListener('click', openNewReviewModal);
}

renderProfile();
renderReviews();

// ---------- Edit Profile Modal ----------
const editProfileModal = document.getElementById('editProfileModal');
const openEditProfile = document.getElementById('openEditProfile');
const closeEditProfile = document.getElementById('closeEditProfile');
const editProfileUsername = document.getElementById('editProfileUsername');
const saveProfileBtn = document.getElementById('saveProfileBtn');

openEditProfile.addEventListener('click', () => {
  const profile = Store.getProfile();
  editProfileUsername.value = `@${profile.username}`;
  editProfileModal.classList.add('active');
});

closeEditProfile.addEventListener('click', () => editProfileModal.classList.remove('active'));
editProfileModal.addEventListener('click', (e) => {
  if (e.target === editProfileModal) editProfileModal.classList.remove('active');
});

saveProfileBtn.addEventListener('click', () => {
  const raw = editProfileUsername.value.trim().replace(/^@/, '');
  if (!raw) {
    alert('Username tidak boleh kosong.');
    return;
  }
  const profile = Store.getProfile();
  profile.username = raw;
  Store.saveProfile(profile);
  renderProfile();
  editProfileModal.classList.remove('active');
});

// ---------- Log a New Film Modal ----------
const newReviewModal = document.getElementById('newReviewModal');
const closeNewReview = document.getElementById('closeNewReview');
const reviewMovieSelect = document.getElementById('reviewMovieSelect');
const newReviewForm = document.getElementById('newReviewForm');

function openNewReviewModal() {
  const movies = Store.getAllMovies();
  reviewMovieSelect.innerHTML = movies
    .map((m) => `<option value="${m.id}">${m.title}</option>`)
    .join('');
  newReviewModal.classList.add('active');
}

closeNewReview.addEventListener('click', () => newReviewModal.classList.remove('active'));
newReviewModal.addEventListener('click', (e) => {
  if (e.target === newReviewModal) newReviewModal.classList.remove('active');
});

newReviewForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const movie = Store.getMovieById(reviewMovieSelect.value);
  const rating = parseFloat(document.getElementById('reviewRating').value);
  const text = document.getElementById('reviewText').value.trim();

  if (!movie || isNaN(rating) || !text) return;

  Store.addReview({
    id: 'rev' + Date.now(),
    movieId: movie.id,
    movieTitle: movie.title,
    rating,
    text,
    likes: 0,
    timeAgo: 'just now',
    poster: movie.poster,
  });

  newReviewForm.reset();
  newReviewModal.classList.remove('active');
  renderReviews();
});
