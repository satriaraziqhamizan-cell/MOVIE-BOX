// ============================================
// STORE — pusat data koleksi film & profil
// Semua halaman baca/tulis lewat objek Store ini
// supaya Add/Edit/Delete/Mark Watched nyambung
// antar halaman (disimpan di localStorage).
//
// CATATAN PENTING:
// Beberapa browser (Firefox, dan Chrome dalam kondisi
// tertentu) MEMBLOKIR localStorage saat file HTML dibuka
// langsung dari komputer (protokol file://), lalu melempar
// SecurityError. Kalau ini terjadi tanpa fallback, seluruh
// script akan berhenti jalan di baris localStorage pertama —
// akibatnya SEMUA tombol (Edit Profile, Add Movie, Reviews,
// dst) terlihat "tidak berfungsi" padahal sebenarnya script-nya
// crash duluan. `safeStorage` di bawah ini mendeteksi kondisi
// itu dan otomatis pakai penyimpanan sementara di memori supaya
// halaman tetap berfungsi normal walau dibuka langsung dari file.
// ============================================

const safeStorage = (() => {
  try {
    const testKey = "__moviebox_test__";
    window.localStorage.setItem(testKey, "1");
    window.localStorage.removeItem(testKey);
    return window.localStorage;
  } catch (e) {
    console.warn(
      "[Moviebox] localStorage tidak tersedia (kemungkinan dibuka lewat file://). " +
      "Menggunakan penyimpanan sementara di memori — data akan reset saat halaman di-refresh."
    );
    const memory = {};
    return {
      getItem: (k) => (Object.prototype.hasOwnProperty.call(memory, k) ? memory[k] : null),
      setItem: (k, v) => { memory[k] = String(v); },
      removeItem: (k) => { delete memory[k]; },
    };
  }
})();

const Store = {
  MOVIES_KEY: "moviebox_movies",
  REVIEWS_KEY: "moviebox_reviews",
  PROFILE_KEY: "moviebox_profile",

  // ---------- MOVIES ----------
  getAllMovies() {
    const raw = safeStorage.getItem(this.MOVIES_KEY);
    if (!raw) {
      this.saveMovies(SEED_MOVIES);
      return [...SEED_MOVIES];
    }
    try {
      return JSON.parse(raw);
    } catch (e) {
      return [...SEED_MOVIES];
    }
  },

  saveMovies(movies) {
    safeStorage.setItem(this.MOVIES_KEY, JSON.stringify(movies));
  },

  getMovieById(id) {
    return this.getAllMovies().find((m) => m.id === id) || null;
  },

  addMovie(movie) {
    const movies = this.getAllMovies();
    movies.unshift(movie);
    this.saveMovies(movies);
  },

  updateMovie(id, changes) {
    const movies = this.getAllMovies();
    const idx = movies.findIndex((m) => m.id === id);
    if (idx !== -1) {
      movies[idx] = { ...movies[idx], ...changes };
      this.saveMovies(movies);
    }
  },

  removeMovie(id) {
    const movies = this.getAllMovies().filter((m) => m.id !== id);
    this.saveMovies(movies);
  },

  // ---------- REVIEWS ----------
  getAllReviews() {
    const raw = safeStorage.getItem(this.REVIEWS_KEY);
    if (!raw) {
      this.saveReviews(SEED_REVIEWS);
      return [...SEED_REVIEWS];
    }
    try {
      return JSON.parse(raw);
    } catch (e) {
      return [...SEED_REVIEWS];
    }
  },

  saveReviews(reviews) {
    safeStorage.setItem(this.REVIEWS_KEY, JSON.stringify(reviews));
  },

  addReview(review) {
    const reviews = this.getAllReviews();
    reviews.unshift(review);
    this.saveReviews(reviews);
  },

  // ---------- PROFILE ----------
  getProfile() {
    const raw = safeStorage.getItem(this.PROFILE_KEY);
    if (!raw) {
      const defaultProfile = { username: "USERNAME", followers: 10, following: 10 };
      this.saveProfile(defaultProfile);
      return defaultProfile;
    }
    try {
      return JSON.parse(raw);
    } catch (e) {
      return { username: "USERNAME", followers: 10, following: 10 };
    }
  },

  saveProfile(profile) {
    safeStorage.setItem(this.PROFILE_KEY, JSON.stringify(profile));
  },

  // ---------- HELPERS ----------
  makeIdFromTitle(title) {
    const base = title
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "");
    let id = base || "movie";
    const existingIds = this.getAllMovies().map((m) => m.id);
    let suffix = 1;
    while (existingIds.includes(id)) {
      suffix += 1;
      id = `${base}-${suffix}`;
    }
    return id;
  },
};
