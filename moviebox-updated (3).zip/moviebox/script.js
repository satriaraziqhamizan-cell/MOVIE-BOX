// Ambil elemen-elemen modal & tombol yang dibutuhkan
const loginModal = document.getElementById('loginModal');
const registerModal = document.getElementById('registerModal');

const openLoginBtn = document.getElementById('openLogin');
const goToRegisterLink = document.getElementById('goToRegister');
const closeButtons = document.querySelectorAll('[data-close]');

const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');

// Fungsi bantu untuk buka & tutup modal
function openModal(modal) {
  modal.classList.add('active');
}

function closeModal(modal) {
  modal.classList.remove('active');
}

function closeAllModals() {
  closeModal(loginModal);
  closeModal(registerModal);
}

// Buka modal LOG IN saat tombol navbar diklik
openLoginBtn.addEventListener('click', () => {
  openModal(loginModal);
});

// Pindah dari modal LOG IN ke modal CREATE ACCOUNT
goToRegisterLink.addEventListener('click', (e) => {
  e.preventDefault();
  closeModal(loginModal);
  openModal(registerModal);
});

// Tombol close (X) di kedua modal
closeButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    closeAllModals();
  });
});

// Tutup modal jika area gelap di luar card diklik
[loginModal, registerModal].forEach((overlay) => {
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) {
      closeAllModals();
    }
  });
});

// Tutup modal dengan tombol ESC
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    closeAllModals();
  }
});

// Handle submit form LOG IN (sementara belum terhubung ke server/database)
loginForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const username = document.getElementById('loginUsername').value;
  const password = document.getElementById('loginPassword').value;

  console.log('Login attempt:', { username, password });
  // TODO: ganti dengan proses autentikasi asli (fetch ke backend/API)
  window.location.href = 'home.html';
});

// Handle submit form CREATE ACCOUNT (sementara belum terhubung ke server/database)
registerForm.addEventListener('submit', (e) => {
  e.preventDefault();
  const email = document.getElementById('regEmail').value;
  const username = document.getElementById('regUsername').value;
  const password = document.getElementById('regPassword').value;

  console.log('Register attempt:', { email, username, password });
  // TODO: ganti dengan proses pendaftaran asli (fetch ke backend/API)
  window.location.href = 'home.html';
});
