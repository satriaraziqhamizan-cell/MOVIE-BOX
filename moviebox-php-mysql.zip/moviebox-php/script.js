// ============================================
// LOGIN & CREATE ACCOUNT - sekarang tersambung
// beneran ke database MySQL lewat api/auth.php
// (dulu cuma console.log doang / belum ke server)
// ============================================

const loginModal = document.getElementById('loginModal');
const registerModal = document.getElementById('registerModal');

const openLoginBtn = document.getElementById('openLogin');
const goToRegisterLink = document.getElementById('goToRegister');
const closeButtons = document.querySelectorAll('[data-close]');

const loginForm = document.getElementById('loginForm');
const registerForm = document.getElementById('registerForm');

// Fungsi bantu untuk buka & tutup modal
function openModal(modal) {
  modal.classList.add('active');
}

function closeModal(modal) {
  modal.classList.remove('active');
}

function closeAllModals() {
  closeModal(loginModal);
  closeModal(registerModal);
}

// Buka modal LOG IN saat tombol navbar diklik
openLoginBtn.addEventListener('click', () => {
  openModal(loginModal);
});

// Pindah dari modal LOG IN ke modal CREATE ACCOUNT
goToRegisterLink.addEventListener('click', (e) => {
  e.preventDefault();
  closeModal(loginModal);
  openModal(registerModal);
});

// Tombol close (X) di kedua modal
closeButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    closeAllModals();
  });
});

// Tutup modal jika area gelap di luar card diklik
[loginModal, registerModal].forEach((overlay) => {
  overlay.addEventListener('click', (e) => {
    if (e.target === overlay) {
      closeAllModals();
    }
  });
});

// Tutup modal dengan tombol ESC
document.addEventListener('keydown', (e) => {
  if (e.key === 'Escape') {
    closeAllModals();
  }
});

// Handle submit form LOG IN -> kirim ke api/auth.php (action: login)
loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const username = document.getElementById('loginUsername').value;
  const password = document.getElementById('loginPassword').value;

  const res = await fetch('api/auth.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'login', username, password }),
  });
  const result = await res.json();

  if (result.success) {
    window.location.href = 'home.html';
  } else {
    alert(result.message || 'Login gagal.');
  }
});

// Handle submit form CREATE ACCOUNT -> kirim ke api/auth.php (action: register)
registerForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = document.getElementById('regEmail').value;
  const username = document.getElementById('regUsername').value;
  const password = document.getElementById('regPassword').value;

  const res = await fetch('api/auth.php', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ action: 'register', email, username, password }),
  });
  const result = await res.json();

  if (result.success) {
    window.location.href = 'home.html';
  } else {
    alert(result.message || 'Registrasi gagal.');
  }
});
