// ============================================
// GENRE FILTER - panel filter genre di topbar
// (getAllGenres & init sekarang async karena
// Store.getAllMovies() ambil data lewat fetch ke API PHP)
// ============================================

const GenreFilter = (function () {
  let activeGenres = new Set();
  let panel = null;
  const onChangeCallbacks = [];

  async function getAllGenres() {
    const movies = await Store.getAllMovies();
    const genres = new Set();
    movies.forEach((m) => {
      m.genre.split(',').forEach((g) => genres.add(g.trim()));
    });
    return [...genres].sort();
  }

  function notify() {
    const active = [...activeGenres];
    onChangeCallbacks.forEach((fn) => fn(active));
  }

  async function buildPanel(searchWrap) {
    const el = document.createElement('div');
    el.className = 'filter-dropdown-panel';
    el.innerHTML = `
      <h3>Filters</h3>
      <div class="filter-group-label">Genre</div>
      <div class="filter-dropdown-list"></div>
    `;

    const list = el.querySelector('.filter-dropdown-list');
    const genres = await getAllGenres();
    genres.forEach((genre) => {
      const label = document.createElement('label');
      label.className = 'filter-checkbox-row';
      label.innerHTML = `<input type="checkbox" value="${genre}"> <span>${genre}</span>`;
      const input = label.querySelector('input');
      input.addEventListener('change', () => {
        if (input.checked) {
          activeGenres.add(genre);
        } else {
          activeGenres.delete(genre);
        }
        notify();
      });
      list.appendChild(label);
    });

    searchWrap.appendChild(el);
    return el;
  }

  async function init() {
    const sortBtn = document.querySelector('.sort-btn');
    const searchWrap = document.querySelector('.topbar-search');
    if (!sortBtn || !searchWrap || typeof Store === 'undefined') return;

    const genres = await getAllGenres();
    if (genres.length === 0) return;

    searchWrap.style.position = 'relative';
    panel = await buildPanel(searchWrap);

    sortBtn.addEventListener('click', (e) => {
      e.stopPropagation();
      panel.classList.toggle('active');
    });

    document.addEventListener('click', (e) => {
      if (panel && panel.classList.contains('active') && !searchWrap.contains(e.target)) {
        panel.classList.remove('active');
      }
    });
  }

  function apply(movies) {
    if (activeGenres.size === 0) return movies;
    return movies.filter((m) =>
      m.genre.split(',').some((g) => activeGenres.has(g.trim()))
    );
  }

  function onChange(fn) {
    onChangeCallbacks.push(fn);
  }

  document.addEventListener('DOMContentLoaded', init);

  return { apply, onChange };
})();
