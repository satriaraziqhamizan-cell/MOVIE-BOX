// ============================================
// WATCHING STATUS — statistik + grid film per status
// (semua fungsi yang pakai Store sekarang async)
// ============================================

const statusGrid = document.getElementById('statusGrid');
const statusTabs = document.querySelectorAll('.status-tab');
let activeFilter = 'all';

async function renderStats() {
  const movies = await Store.getAllMovies();
  const watched = movies.filter((m) => m.status === 'watched').length;
  const want = movies.filter((m) => m.status === 'want').length;

  document.getElementById('statTotal').textContent = movies.length;
  document.getElementById('statWatched').textContent = watched;
  document.getElementById('statWant').textContent = want;
}

async function getFilteredMovies() {
  let movies = await Store.getAllMovies();

  if (activeFilter !== 'all') {
    movies = movies.filter((m) => m.status === activeFilter);
  }

  if (typeof GenreFilter !== 'undefined') {
    movies = GenreFilter.apply(movies);
  }

  return movies;
}

async function renderGrid() {
  const movies = await getFilteredMovies();

  statusGrid.innerHTML = '';

  if (movies.length === 0) {
    statusGrid.innerHTML = `<p class="empty-state">Tidak ada film di kategori ini.</p>`;
    return;
  }

  movies.forEach((movie) => {
    const card = document.createElement('a');
    card.className = 'movie-card';
    card.href = `detail.html?id=${movie.id}`;
    card.innerHTML = `
      <div class="movie-poster" style="background-image:${movie.poster};">
        ${movie.poster.startsWith('url') ? '' : movie.title}
      </div>
      <div class="movie-title-bar">${movie.title}</div>
      <div class="movie-meta">
        <span class="movie-rating">
          <svg viewBox="0 0 24 24"><path d="M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1L12 2z"/></svg>
          ${movie.rating.toFixed(1)}
        </span>
        <span class="movie-duration">${movie.duration}</span>
      </div>
    `;
    statusGrid.appendChild(card);
  });
}

statusTabs.forEach((tab) => {
  tab.addEventListener('click', () => {
    statusTabs.forEach((t) => t.classList.remove('active'));
    tab.classList.add('active');
    activeFilter = tab.dataset.filter;
    renderGrid();
  });
});

// Filter genre — panel dibuka lewat tombol panah (sort-btn) di topbar
if (typeof GenreFilter !== 'undefined') {
  GenreFilter.onChange(() => {
    renderGrid();
  });
}

renderStats();
renderGrid();
