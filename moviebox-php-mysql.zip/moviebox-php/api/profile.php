<?php
/* ============================================
   profile.php — API untuk data profil (username,
   followers, following) di halaman Profile.
   Untuk versi sederhana ini cuma ada 1 baris profil
   (baris id=1) — belum dipisah per-user login.

   - GET             -> ambil profil
   - POST action=save -> update profil
   ============================================ */

require 'db.php';
header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
    $stmt = $pdo->query("SELECT username, followers, following FROM profile WHERE id = 1");
    $profile = $stmt->fetch(PDO::FETCH_ASSOC);
    if (!$profile) {
        $profile = ['username' => 'USERNAME', 'followers' => 10, 'following' => 10];
    } else {
        $profile['followers'] = (int)$profile['followers'];
        $profile['following'] = (int)$profile['following'];
    }
    echo json_encode($profile);
    exit;
}

if ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $action = $data['action'] ?? '';

    if ($action === 'save') {
        $stmt = $pdo->prepare("UPDATE profile SET username = ? WHERE id = 1");
        $stmt->execute([$data['username'] ?? 'USERNAME']);
        echo json_encode(['success' => true]);
        exit;
    }

    echo json_encode(['error' => 'Unknown POST action']);
    exit;
}
