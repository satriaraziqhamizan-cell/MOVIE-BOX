<?php
/* ============================================
   movies.php — API untuk data film.
   Menggantikan Store.getAllMovies / getMovieById /
   addMovie / updateMovie / removeMovie yang dulu
   nyimpen ke localStorage.

   Cara kerja: browser (store.js) kirim request lewat
   fetch(), file ini baca/tulis ke tabel `movies` di
   MySQL, lalu balas dalam format JSON.

   - GET  ?action=all          -> semua film
   - GET  ?action=get&id=xxx   -> 1 film
   - POST action=add           -> tambah film baru
   - POST action=update        -> update film (id + changes)
   - POST action=delete        -> hapus film (id)
   ============================================ */

require 'db.php';
header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

// Ubah 1 baris hasil query jadi tipe data yang benar
// (MySQL selalu balikin string, padahal di JS kita butuh number/boolean).
function formatMovie($m) {
    if (!$m) return null;
    $m['year']   = (int)$m['year'];
    $m['rating'] = (float)$m['rating'];
    $m['saved']  = (bool)$m['saved'];
    return $m;
}

if ($method === 'GET') {
    $action = $_GET['action'] ?? 'all';

    if ($action === 'all') {
        $stmt = $pdo->query("SELECT * FROM movies ORDER BY created_at DESC");
        $movies = array_map('formatMovie', $stmt->fetchAll(PDO::FETCH_ASSOC));
        echo json_encode($movies);
        exit;
    }

    if ($action === 'get') {
        $id = $_GET['id'] ?? '';
        $stmt = $pdo->prepare("SELECT * FROM movies WHERE id = ?");
        $stmt->execute([$id]);
        $movie = $stmt->fetch(PDO::FETCH_ASSOC);
        echo json_encode(formatMovie($movie));
        exit;
    }

    echo json_encode(['error' => 'Unknown GET action']);
    exit;
}

if ($method === 'POST') {
    // Data dikirim sebagai JSON di body request, bukan $_POST biasa,
    // karena store.js kirim pakai fetch(..., { body: JSON.stringify(...) })
    $data = json_decode(file_get_contents('php://input'), true);
    $action = $data['action'] ?? '';

    if ($action === 'add') {
        $stmt = $pdo->prepare(
            "INSERT INTO movies (id, title, year, genre, director, duration, rating, synopsis, status, saved, added_date, poster)
             VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"
        );
        $stmt->execute([
            $data['id'],
            $data['title'],
            $data['year'],
            $data['genre'],
            $data['director'],
            $data['duration'],
            $data['rating'],
            $data['synopsis'],
            $data['status'],
            !empty($data['saved']) ? 1 : 0,
            $data['addedDate'],
            $data['poster'],
        ]);
        echo json_encode(['success' => true]);
        exit;
    }

    if ($action === 'update') {
        $id = $data['id'] ?? '';
        $changes = $data['changes'] ?? [];

        // Whitelist kolom yang boleh diupdate, supaya aman dari input aneh-aneh.
        $allowedColumns = ['title', 'genre', 'year', 'director', 'duration', 'rating', 'synopsis', 'status', 'saved'];

        $setParts = [];
        $values = [];
        foreach ($changes as $key => $value) {
            if (in_array($key, $allowedColumns, true)) {
                $setParts[] = "$key = ?";
                $values[] = ($key === 'saved') ? (!empty($value) ? 1 : 0) : $value;
            }
        }

        if (!empty($setParts)) {
            $values[] = $id;
            $sql = "UPDATE movies SET " . implode(', ', $setParts) . " WHERE id = ?";
            $pdo->prepare($sql)->execute($values);
        }

        echo json_encode(['success' => true]);
        exit;
    }

    if ($action === 'delete') {
        $id = $data['id'] ?? '';
        $stmt = $pdo->prepare("DELETE FROM movies WHERE id = ?");
        $stmt->execute([$id]);
        echo json_encode(['success' => true]);
        exit;
    }

    echo json_encode(['error' => 'Unknown POST action']);
    exit;
}
