// ============================================
// SEARCH RESULTS — filter genre + keyword dari query string
// (getAllGenres, renderGenreFilters, renderResults sekarang async)
// ============================================

const searchParams = new URLSearchParams(window.location.search);
const initialQuery = searchParams.get('q') || '';

const searchQueryLabel = document.getElementById('searchQueryLabel');
const searchResultsGrid = document.getElementById('searchResultsGrid');
const genreFilterList = document.getElementById('genreFilterList');
const searchPageInput = document.getElementById('searchPageInput');

searchQueryLabel.textContent = initialQuery;
searchPageInput.value = initialQuery;

let activeGenres = new Set();

async function getAllGenres() {
  const movies = await Store.getAllMovies();
  const genreSet = new Set();
  movies.forEach((m) => {
    m.genre.split(',').forEach((g) => genreSet.add(g.trim()));
  });
  return [...genreSet].sort();
}

async function renderGenreFilters() {
  const genres = await getAllGenres();
  genreFilterList.innerHTML = genres
    .map(
      (g) => `
      <label class="filter-checkbox-row">
        <input type="checkbox" value="${g}" class="genre-checkbox">
        ${g}
      </label>
    `
    )
    .join('');

  genreFilterList.querySelectorAll('.genre-checkbox').forEach((cb) => {
    cb.addEventListener('change', () => {
      if (cb.checked) {
        activeGenres.add(cb.value);
      } else {
        activeGenres.delete(cb.value);
      }
      renderResults();
    });
  });
}

async function renderResults() {
  const keyword = searchQueryLabel.textContent.toLowerCase();
  let movies = await Store.getAllMovies();

  if (keyword.trim()) {
    movies = movies.filter((m) => m.title.toLowerCase().includes(keyword));
  }

  if (activeGenres.size > 0) {
    movies = movies.filter((m) =>
      [...activeGenres].some((g) => m.genre.includes(g))
    );
  }

  searchResultsGrid.innerHTML = '';

  if (movies.length === 0) {
    searchResultsGrid.innerHTML = `<p class="no-results">Tidak ada film yang cocok.</p>`;
    return;
  }

  movies.forEach((movie) => {
    const card = document.createElement('a');
    card.className = 'search-result-card';
    card.href = `detail.html?id=${movie.id}`;
    card.innerHTML = `
      <div class="search-result-poster" style="background-image:${movie.poster};">
        <span class="search-result-rating">
          <svg viewBox="0 0 24 24" width="10" height="10" fill="#f2c94c"><path d="M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1L12 2z"/></svg>
          ${movie.rating.toFixed(1)}
        </span>
      </div>
      <h4>${movie.title}</h4>
      <p>${movie.year} • ${movie.genre}</p>
    `;
    searchResultsGrid.appendChild(card);
  });
}

searchPageInput.addEventListener('input', (e) => {
  searchQueryLabel.textContent = e.target.value;
  renderResults();
});

searchPageInput.addEventListener('keydown', (e) => {
  if (e.key === 'Enter') {
    e.preventDefault();
    renderResults();
  }
});

renderGenreFilters();
renderResults();
