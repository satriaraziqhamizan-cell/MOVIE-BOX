-- ============================================
-- database.sql — schema + data awal untuk MovieBox
--
-- CARA IMPORT (XAMPP):
-- 1. Buka XAMPP Control Panel, klik Start di Apache & MySQL.
-- 2. Buka browser -> http://localhost/phpmyadmin
-- 3. Klik tab "SQL" di bagian atas.
-- 4. Copy-paste SELURUH isi file ini, lalu klik "Go" / "Kirim".
--    (phpMyAdmin akan otomatis bikin database moviebox_db-nya)
-- ============================================

CREATE DATABASE IF NOT EXISTS moviebox_db CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE moviebox_db;

-- ---------- Tabel users (untuk Login/Create Account) ----------
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL UNIQUE,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,   -- disimpan dalam bentuk hash, bukan teks asli
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------- Tabel movies (dulunya SEED_MOVIES di movies-data.js) ----------
CREATE TABLE IF NOT EXISTS movies (
  id VARCHAR(100) PRIMARY KEY,
  title VARCHAR(150) NOT NULL,
  year INT NOT NULL,
  genre VARCHAR(100) NOT NULL,
  director VARCHAR(100) NOT NULL,
  duration VARCHAR(30) NOT NULL,
  rating DECIMAL(3,1) NOT NULL DEFAULT 0,
  synopsis TEXT,
  status ENUM('watched','want') NOT NULL DEFAULT 'want',
  saved TINYINT(1) NOT NULL DEFAULT 1,
  added_date DATE NOT NULL,
  -- poster pakai TEXT (bukan VARCHAR) karena kalau user upload gambar,
  -- gambarnya disimpan sebagai base64 data-URL yang bisa sangat panjang
  poster TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- ---------- Tabel reviews (dulunya SEED_REVIEWS) ----------
CREATE TABLE IF NOT EXISTS reviews (
  id VARCHAR(100) PRIMARY KEY,
  movie_id VARCHAR(100) NOT NULL,
  movie_title VARCHAR(150) NOT NULL,
  rating DECIMAL(3,1) NOT NULL,
  text TEXT NOT NULL,
  likes INT NOT NULL DEFAULT 0,
  time_ago VARCHAR(50) DEFAULT 'just now',
  poster TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (movie_id) REFERENCES movies(id) ON DELETE CASCADE
);

-- ---------- Tabel profile (satu baris data profil) ----------
CREATE TABLE IF NOT EXISTS profile (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL DEFAULT 'USERNAME',
  followers INT NOT NULL DEFAULT 10,
  following INT NOT NULL DEFAULT 10
);

INSERT INTO profile (id, username, followers, following) VALUES (1, 'USERNAME', 10, 10);

-- ---------- Data awal film (persis dari SEED_MOVIES) ----------
INSERT INTO movies (id, title, year, genre, director, duration, rating, synopsis, status, saved, added_date, poster) VALUES
('spiderman', 'Spiderman', 2012, 'Superhero', 'Marc Webb', '2h 30m', 7.0, 'A teenager bitten by a genetically altered spider gains powers and must learn to use them while uncovering secrets from his parents'' past.', 'watched', 1, '2023-09-02', "url('image/posters/spiderman.jpg')"),
('menace-ii', 'Menace II', 1993, 'Crime, Drama', 'Hughes Brothers', '3h 5m', 7.5, 'A young man growing up in a rough neighborhood struggles to escape a cycle of violence closing in around him.', 'watched', 1, '2023-09-10', "url('image/posters/menace-ii.jpg')"),
('big-hero-6', 'Big Hero 6', 2014, 'Animation, Family', 'Don Hall', '1h 42m', 7.8, 'A young robotics prodigy and his inflatable companion robot team up with friends to uncover a conspiracy in their city.', 'want', 1, '2023-09-14', "url('image/posters/big-hero-6.jpg')"),
('scarface', 'Scarface', 1983, 'Crime, Drama', 'Brian De Palma', '2h 14m', 8.3, 'An ambitious Cuban immigrant rises to power in Miami''s criminal underworld, only to be consumed by his own greed and paranoia.', 'want', 1, '2023-09-20', "url('image/posters/scarface.jpg')"),
('catch-me-if-you-can', 'Catch Me If...', 2002, 'Crime, Drama', 'Steven Spielberg', '2h 24m', 8.0, 'A skilled con artist poses as a pilot, doctor, and lawyer while a determined FBI agent chases him across the country.', 'want', 1, '2023-09-24', "url('image/posters/catch-me-if-you-can.jpg')"),
('el-camino', 'El Camino', 2019, 'Crime', 'Vince Gilligan', '2h 14m', 7.3, 'In the aftermath of his escape, a fugitive must confront his past in order to secure his future.', 'want', 1, '2023-10-01', "url('image/posters/el-camino.jpg')"),
('2-fnf', '2 FNF', 2003, 'Action', 'John Singleton', '2h 24m', 6.0, 'A former cop and his old partner take on a dangerous undercover job involving a ruthless drug lord.', 'want', 1, '2023-10-05', "url('image/posters/2-fnf.jpg')"),
('toy-story', 'Toy Story', 2019, 'Animation, Family', 'Josh Cooley', '1h 49m', 7.6, 'When a new handmade toy joins the group, a road trip reveals how big the world can be for a toy.', 'want', 1, '2023-10-08', "url('image/posters/toy-story.jpg')"),
('dark-knight', 'Dark Knight', 2008, 'Action, Crime', 'Christopher Nolan', '2h 32m', 9.1, 'A vigilante confronts an agent of chaos who plunges his city into anarchy, testing the limits of his own principles.', 'watched', 1, '2023-10-12', "url('image/posters/dark-knight.jpg')"),
('fight-club', 'Fight Club', 1999, 'Thriller, Dark Comedy', 'David Fincher', '2h 19m', 8.8, 'An insomniac office worker and a devil-may-care soap maker form an underground fight club that evolves into much more.', 'watched', 1, '2023-10-24', "url('image/posters/fight-club.jpg')");

-- ---------- Data awal review (persis dari SEED_REVIEWS) ----------
INSERT INTO reviews (id, movie_id, movie_title, rating, text, likes, time_ago, poster) VALUES
('rev1', 'spiderman', 'Spiderman', 4.5, 'Aksinya seru dan efeknya masih enak ditonton walau sudah lama.', 12, '2 days ago', "url('image/posters/spiderman.jpg')"),
('rev2', 'menace-ii', 'Menace II Society', 5.0, 'Aktingnya kuat banget, ceritanya juga berat tapi worth it.', 45, '1 week ago', "url('image/posters/menace-ii.jpg')");
