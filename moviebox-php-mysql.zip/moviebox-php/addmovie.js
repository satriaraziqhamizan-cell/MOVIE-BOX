// ============================================
// ADD MOVIE - handle upload preview, status toggle,
// dan submit form (simpan ke database via Store/API)
// ============================================

const posterInput = document.getElementById('posterInput');
const uploadPlaceholder = document.getElementById('uploadPlaceholder');
const uploadPreview = document.getElementById('uploadPreview');
const scanPosterBtn = document.getElementById('scanPosterBtn');
let uploadedPosterDataUrl = null;

// Tombol "Scan Poster Image" nonaktif sampai ada poster yang diupload
scanPosterBtn.disabled = true;

posterInput.addEventListener('change', (e) => {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();
  reader.onload = (ev) => {
    uploadedPosterDataUrl = ev.target.result;
    uploadPreview.style.backgroundImage = `url('${uploadedPosterDataUrl}')`;
    uploadPreview.style.display = 'block';
    uploadPlaceholder.style.display = 'none';
    scanPosterBtn.disabled = false;
  };
  reader.readAsDataURL(file);
});

// AI Auto-Fill: fitur simulasi. Belum ada model pengenalan gambar
// sungguhan di balik ini, jadi tombolnya cuma kasih tahu pengguna
// untuk isi form secara manual di sisi kanan.
scanPosterBtn.addEventListener('click', () => {
  const original = scanPosterBtn.textContent;
  scanPosterBtn.textContent = 'Scanning...';
  scanPosterBtn.disabled = true;
  setTimeout(() => {
    scanPosterBtn.textContent = original;
    scanPosterBtn.disabled = false;
    document.getElementById('movieTitle').focus();
    alert('AI Auto-Fill isn\'t available in this version yet. Please fill in the movie details manually on the right.');
  }, 700);
});

// Status toggle (Want to Watch / Watched)
const statusToggles = document.querySelectorAll('.status-toggle');
const watchStatusValue = document.getElementById('watchStatusValue');

statusToggles.forEach((el) => {
  el.addEventListener('click', () => {
    statusToggles.forEach((t) => t.classList.remove('selected'));
    el.classList.add('selected');
    watchStatusValue.value = el.dataset.value;
  });
});


const GRADIENT_POOL = [
  "linear-gradient(160deg,#7a1f2b,#1b1b1b)",
  "linear-gradient(160deg,#123a6e,#03102b)",
  "linear-gradient(160deg,#2f7fd6,#12336b)",
  "linear-gradient(160deg,#8f1c1c,#1b0000)",
  "linear-gradient(160deg,#c2185b,#1b1b1b)",
  "linear-gradient(160deg,#1c3d8f,#0a1330)",
];

function randomGradient() {
  return GRADIENT_POOL[Math.floor(Math.random() * GRADIENT_POOL.length)];
}

// Submit form
// (async karena Store.makeIdFromTitle & Store.addMovie sekarang
// menunggu jawaban dari server lewat fetch/PHP)
document.getElementById('addMovieForm').addEventListener('submit', async (e) => {
  e.preventDefault();

  const title = document.getElementById('movieTitle').value.trim();
  const genre = document.getElementById('movieGenre').value;
  const year = parseInt(document.getElementById('movieYear').value, 10);
  const director = document.getElementById('movieDirector').value.trim();
  const duration = document.getElementById('movieDuration').value.trim();
  const rating = parseFloat(document.getElementById('movieRating').value);
  const synopsis = document.getElementById('movieSynopsis').value.trim();
  const status = watchStatusValue.value;

  if (!title || !genre || !year || !director || !duration || isNaN(rating) || !synopsis) {
    alert('Please fill in all fields first.');
    return;
  }

  const newMovie = {
    id: await Store.makeIdFromTitle(title),
    title,
    genre,
    year,
    director,
    duration,
    rating,
    synopsis,
    status,
    saved: true,
    addedDate: new Date().toISOString().slice(0, 10),
    poster: uploadedPosterDataUrl ? `url('${uploadedPosterDataUrl}')` : randomGradient(),
  };

  await Store.addMovie(newMovie);
  window.location.href = `detail.html?id=${newMovie.id}`;
});
