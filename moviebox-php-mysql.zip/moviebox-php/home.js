// ============================================
// HOME PAGE - render grid film dari Store (via API PHP)
// ============================================

const movieGrid = document.getElementById('movieGrid');
const searchInput = document.querySelector('.search-box input');

function renderMovies(movies) {
  movieGrid.innerHTML = '';

  if (movies.length === 0) {
    movieGrid.innerHTML = `<p class="empty-state">Belum ada film. Klik "+Add movie" untuk menambahkan.</p>`;
    return;
  }

  movies.forEach((movie) => {
    const card = document.createElement('a');
    card.className = 'movie-card';
    card.href = `detail.html?id=${movie.id}`;

    card.innerHTML = `
      <div class="movie-poster" style="background-image:${movie.poster};">
        ${movie.poster.startsWith('url') ? '' : movie.title}
      </div>
      <div class="movie-title-bar">${movie.title}</div>
      <div class="movie-meta">
        <span class="movie-rating">
          <svg viewBox="0 0 24 24"><path d="M12 2l3.1 6.3 6.9 1-5 4.9 1.2 6.8L12 17.8 5.8 21l1.2-6.8-5-4.9 6.9-1L12 2z"/></svg>
          ${movie.rating.toFixed(1)}
        </span>
        <span class="movie-duration">${movie.duration}</span>
      </div>
    `;

    movieGrid.appendChild(card);
  });
}

// Untuk menggabung keyword search + filter genre
// (async karena sekarang Store.getAllMovies() ambil data dari server/database)
async function getFilteredMovies() {
  const keyword = searchInput ? searchInput.value.toLowerCase() : '';
  let movies = await Store.getAllMovies();

  if (keyword.trim()) {
    movies = movies.filter((m) => m.title.toLowerCase().includes(keyword));
  }

  if (typeof GenreFilter !== 'undefined') {
    movies = await GenreFilter.apply(movies);
  }

  return movies;
}

async function refresh() {
  renderMovies(await getFilteredMovies());
}

refresh();

// Tombol "+Add movie"
const addMovieBtn = document.getElementById('addMovieBtn');
if (addMovieBtn) {
  addMovieBtn.addEventListener('click', () => {
    window.location.href = 'addmovie.html';
  });
}

// Search sederhana di grid (live filter, terpisah dari dropdown topbar)
if (searchInput) {
  searchInput.addEventListener('input', () => {
    refresh();
  });
}

// Filter genre - panel dibuka lewat tombol panah (sort-btn) di topbar
if (typeof GenreFilter !== 'undefined') {
  GenreFilter.onChange(() => {
    refresh();
  });
}
