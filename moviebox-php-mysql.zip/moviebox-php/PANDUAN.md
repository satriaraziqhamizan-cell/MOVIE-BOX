# MovieBox + PHP & MySQL — Panduan Lengkap

Ini adalah project MovieBox kamu (HTML/CSS/JS) yang sudah disambungkan ke
**PHP** dan **MySQL** lewat XAMPP. Dokumen ini menjelaskan **konsepnya**
dulu, baru **langkah instalasinya**.

---

## 1. Konsep dasar: kenapa butuh PHP?

Project asli kamu nyimpen semua data film di **localStorage** — itu
artinya data cuma tersimpan di browser kamu sendiri, hilang kalau ganti
device/browser, dan orang lain nggak bisa lihat data yang sama.

Susunan sekarang jadi 3 lapis:

```
[ HTML/CSS/JS di browser ]  --fetch()-->  [ PHP di server ]  --SQL-->  [ MySQL ]
     (tampilan / UI)             (jembatan)         (jembatan)      (databasenya)
```

- **HTML/CSS** — tetap sama persis seperti sebelumnya, ini yang dilihat user.
- **JavaScript (di browser)** — sekarang bukan langsung baca `localStorage`,
  tapi manggil `fetch()` ke file PHP untuk minta/kirim data.
- **PHP (di server / XAMPP)** — nerima request dari JS, ngobrol ke MySQL
  pakai SQL, terus balikin jawaban dalam format **JSON** ke JS.
- **MySQL** — tempat data film, review, profil, dan akun user beneran
  disimpan secara permanen di dalam tabel-tabel.

Kenapa harus lewat PHP, nggak langsung JS ke MySQL? Karena JavaScript di
browser (client-side) **tidak boleh** langsung konek ke database — kalau
bisa, semua orang yang buka website kamu bisa lihat username/password
database kamu lewat "Inspect Element". PHP jalan di **server**, jadi
kredensial database aman, dan PHP-lah yang jadi "penjaga pintu".

---

## 2. Apa yang berubah dari project lama kamu

| Dulu (localStorage)              | Sekarang (PHP + MySQL)                     |
|-----------------------------------|---------------------------------------------|
| `movies-data.js` (data hardcode) | Tabel `movies` di database (file `database.sql`) |
| `store.js` baca/tulis `localStorage` | `store.js` sekarang `fetch()` ke `api/movies.php` dkk |
| Data hilang kalau ganti browser  | Data permanen, semua browser bisa akses data yang sama |
| Login/Register cuma `console.log` | `script.js` beneran kirim ke `api/auth.php`, password di-hash |

**Penting:** nama-nama fungsi di `Store` (`getAllMovies`, `addMovie`, dst)
**sengaja dibiarkan sama**. Bedanya, sekarang semua fungsi itu `async`
(mengembalikan Promise) karena harus menunggu jawaban dari server. Jadi di
semua file JS yang manggil `Store.xxx(...)`, sekarang dipanggil dengan
`await Store.xxx(...)` di dalam fungsi `async`. Bandingkan file JS lama vs
baru kalau mau lihat persis bagian mana yang berubah.

File baru yang ditambahkan:
- **`database.sql`** — perintah SQL untuk bikin database + tabel + isi data awal.
- **`api/db.php`** — konfigurasi koneksi ke MySQL (host, nama database, dst).
- **`api/movies.php`** — CRUD film (list, tambah, edit, hapus).
- **`api/reviews.php`** — list & tambah review.
- **`api/profile.php`** — ambil & simpan profil.
- **`api/auth.php`** — register & login beneran (password di-hash, bukan disimpan mentah).

---

## 3. Instalasi (VS Code + XAMPP)

### Langkah 1 — Taruh folder project ke `htdocs`
PHP hanya bisa jalan lewat server Apache, bukan cuma dibuka double-click
seperti file HTML biasa. Maka:

1. Install XAMPP kalau belum ada (https://www.apachefriends.org).
2. Cari folder instalasi XAMPP, biasanya `C:\xampp\htdocs\` (Windows) atau
   `/Applications/XAMPP/htdocs/` (Mac).
3. Copy **seluruh folder** `moviebox-php` ini ke dalam `htdocs`, misalnya
   jadi `C:\xampp\htdocs\moviebox-php`.

### Langkah 2 — Nyalakan Apache & MySQL
1. Buka **XAMPP Control Panel**.
2. Klik **Start** di baris `Apache` dan `MySQL`. Keduanya harus hijau/running.

### Langkah 3 — Import database
1. Buka browser, ke `http://localhost/phpmyadmin`.
2. Klik tab **SQL** di bagian atas halaman.
3. Buka file `database.sql` (di folder project ini) pakai VS Code, copy
   semua isinya, paste ke kotak SQL di phpMyAdmin.
4. Klik tombol **Go / Kirim**.
5. Kalau berhasil, akan muncul database baru bernama `moviebox_db` di
   sidebar kiri, isinya 4 tabel: `users`, `movies`, `reviews`, `profile`.

### Langkah 4 — Buka websitenya
Jangan buka `index.html` dengan cara double-click file (itu akan pakai
`file://`, dan PHP **tidak akan jalan** di situ). Harus lewat Apache:

```
http://localhost/moviebox-php/index.html
```

Kalau folder yang kamu copy namanya beda (misal `htdocs/movieboxku`),
sesuaikan URL-nya jadi `http://localhost/movieboxku/index.html`.

### Langkah 5 — Coba tes
- Buka Home, film-nya sekarang datang dari database (bukan `movies-data.js` lagi).
- Coba tambah film baru lewat "+Add movie" → cek di phpMyAdmin, tabel
  `movies` akan bertambah barisnya.
- Coba Create Account & Login di halaman awal → cek tabel `users`.

---

## 4. Kalau error

- **"Koneksi database gagal"** → pastikan MySQL sudah Start di XAMPP, dan
  `database.sql` sudah diimport. Cek juga `api/db.php`: nama database,
  user (`root`), password (kosong secara default) harus cocok dengan
  setup XAMPP kamu.
- **Halaman putih kosong / kode PHP muncul sebagai teks** → berarti kamu
  membuka file lewat `file://` bukan `http://localhost/...`. Harus lewat Apache.
- **Data nggak nongol / error di Console (F12)** → cek tab **Network** di
  DevTools browser, klik salah satu request ke `api/movies.php`, lihat
  responsenya — biasanya pesan error PHP muncul di situ.

---

## 5. Struktur folder

```
moviebox-php/
├── api/                  <- PHP backend (baru)
│   ├── db.php            <- koneksi ke MySQL
│   ├── movies.php        <- CRUD film
│   ├── reviews.php       <- review
│   ├── profile.php       <- profil
│   └── auth.php          <- login/register
├── css/                  <- tidak berubah
├── image/                <- tidak berubah
├── database.sql          <- schema + data awal (baru)
├── store.js              <- diubah: sekarang fetch ke api/, bukan localStorage
├── home.js, detail.js, ...  <- diubah: pakai async/await
├── *.html                <- hampir sama, cuma buang <script src="movies-data.js">
└── PANDUAN.md             <- file ini
```

Kalau nanti mau lanjut belajar, langkah berikutnya yang wajar: pisahkan
data film per user (sekarang semua user share 1 koleksi film yang sama),
pakai session PHP dari `api/auth.php` untuk itu.
