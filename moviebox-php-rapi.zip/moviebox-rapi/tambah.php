<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Moviebox - Add New Movie</title>
  <link rel="stylesheet" href="css/home.css">
</head>
<body>

  <div class="app-layout">

    <aside class="sidebar">
      <div class="sidebar-avatar">
        <img src="image/avatar.png" alt="Moviebox">
      </div>

      <nav class="sidebar-nav">
        <a class="sidebar-btn add-movie" href="tambah.php">+ Add movie</a>
        <a class="sidebar-btn" href="profile.html">Reviews</a>
        <a class="sidebar-btn" href="watching-status.html">Watching Status</a>
      </nav>

      <div class="sidebar-spacer"></div>
      <img src="image/Logo.png" alt="Moviebox" class="sidebar-logo">
    </aside>

    <main class="main-content">

      <div class="topbar">
        <div class="topbar-tabs">
          <a href="index.php">Home</a>
          <a href="mylist.html">My list</a>
        </div>
        <div class="topbar-search">
          <div class="search-box">
            <svg viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27a6.5 6.5 0 1 0-.7.7l.27.28v.79l5 5L20.5 19l-5-5zm-6 0a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9z"/></svg>
            <input type="text" placeholder="Search">
          </div>
          <button class="sort-btn" title="Sort">
            <svg viewBox="0 0 24 24"><path d="M7 4l-4 4h3v8h2V8h3L7 4zm10 16l4-4h-3V8h-2v8h-3l4 4z"/></svg>
          </button>
        </div>
      </div>

      <form id="addMovieForm">
        <div class="form-topbar">
          <div>
            <h1>ADD NEW MOVIE</h1>
            <p>Expand your cinematic universe. Enter the details below to add a new title to your collection.</p>
          </div>
          <div class="form-topbar-actions">
            <a class="btn-cancel-pill" href="index.php">Cancel</a>
            <button type="submit" class="btn-save">Save Movie</button>
          </div>
        </div>

        <div class="addmovie-grid">
          <div class="upload-col">
            <label class="upload-box" id="uploadBox">
              <div id="uploadPlaceholder">
                <svg viewBox="0 0 24 24"><path d="M19 13v6H5v-6H3v6c0 1.1.9 2 2 2h14c1.1 0 2-.9 2-2v-6h-2zM13 3h-2v9.67L7.5 9.17 6.09 10.6 12 16.5l5.91-5.9-1.41-1.43L13 12.67V3z"/></svg>
                <h4>Upload Poster</h4>
                <p>Drag and drop or click to browse</p>
                <p>JPG, PNG (MAX 5MB)</p>
              </div>
              <div class="upload-preview" id="uploadPreview" style="display:none;"></div>
              <input type="file" id="posterInput" accept="image/*">
            </label>

            <div class="autofill-box">
              <span class="tag">AI AUTO-FILL</span>
              <p>Upload a poster first, and our system will attempt to populate the movie details below based on image recognition.</p>
              <button type="button" class="btn-scan-poster" id="scanPosterBtn">Scan Poster Image</button>
            </div>
          </div>

          <div class="details-col">
            <div class="form-section">
              <h3>Core Details</h3>
              <div class="field">
                <label for="movieTitle">Movie Title</label>
                <input type="text" id="movieTitle" placeholder="e.g. Inception, The Matrix..." required>
              </div>
              <div class="field-row">
                <div class="field">
                  <label for="movieGenre">Genre</label>
                  <select id="movieGenre" required>
                    <option value="" disabled selected>Select a genre...</option>
                    <option>Action</option>
                    <option>Adventure</option>
                    <option>Animation, Family</option>
                    <option>Comedy</option>
                    <option>Crime, Drama</option>
                    <option>Drama</option>
                    <option>Horror</option>
                    <option>Romance</option>
                    <option>Sci-Fi</option>
                    <option>Superhero</option>
                    <option>Thriller, Dark Comedy</option>
                  </select>
                </div>
                <div class="field">
                  <label for="movieYear">Release Year</label>
                  <input type="number" id="movieYear" placeholder="YYYY" min="1900" max="2100" required>
                </div>
              </div>
              <div class="field">
                <label for="movieDirector">Director</label>
                <input type="text" id="movieDirector" placeholder="e.g. Christopher Nolan" required>
              </div>
              <div class="field-row">
                <div class="field">
                  <label for="movieDuration">Duration</label>
                  <input type="text" id="movieDuration" placeholder="e.g. 2h 14m" required>
                </div>
                <div class="field">
                  <label for="movieRating">Rating (0-10)</label>
                  <input type="number" id="movieRating" placeholder="e.g. 8.0" min="0" max="10" step="0.1" required>
                </div>
              </div>
              <div class="field">
                <label for="movieSynopsis">Synopsis</label>
                <textarea id="movieSynopsis" rows="3" placeholder="A short summary of the movie..." required></textarea>
              </div>
            </div>

            <div class="form-section">
              <h3>Watch Status</h3>
              <div class="status-toggle-row">
                <div class="status-toggle selected" data-value="want" id="statusWant">
                  <svg viewBox="0 0 24 24"><path d="M17 3H7a2 2 0 0 0-2 2v16l7-3 7 3V5a2 2 0 0 0-2-2z"/></svg>
                  <strong>Want to Watch</strong>
                  <span>Add to your backlog</span>
                </div>
                <div class="status-toggle" data-value="watched" id="statusWatched">
                  <svg viewBox="0 0 24 24"><path d="M12 4.5C7 4.5 2.7 7.6 1 12c1.7 4.4 6 7.5 11 7.5s9.3-3.1 11-7.5c-1.7-4.4-6-7.5-11-7.5zM12 17a5 5 0 1 1 0-10 5 5 0 0 1 0 10zm0-8a3 3 0 1 0 0 6 3 3 0 0 0 0-6z"/></svg>
                  <strong>Watched</strong>
                  <span>Already seen it</span>
                </div>
              </div>
              <input type="hidden" id="watchStatusValue" value="want">
            </div>
          </div>
        </div>
      </form>

    </main>
  </div>

  <script src="store.js"></script>
  <script src="search-dropdown.js"></script>
  <script src="tambah.js"></script>
</body>
</html>
