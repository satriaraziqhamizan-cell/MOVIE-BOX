// ============================================
// EDIT FILM - load data existing, update ke database
// (loadMovie & submit handler sekarang async)
// ============================================

const editParams = new URLSearchParams(window.location.search);
const editMovieId = editParams.get('id');

const form = document.getElementById('editMovieForm');
const posterBox = document.getElementById('editPosterBox');
const statusRow = document.getElementById('editStatusRow');
const statusButtons = statusRow.querySelectorAll('.pill-choice');

let currentStatus = 'want';

async function loadMovie() {
  const movie = await Store.getMovieById(editMovieId);
  if (!movie) {
    form.innerHTML = `<p class="empty-state">Film tidak ditemukan. <a href="index.php" style="color:#f2c94c;">Kembali ke Home</a></p>`;
    return;
  }

  posterBox.style.backgroundImage = movie.poster;
  document.getElementById('editTitle').value = movie.title;
  document.getElementById('editGenre').value = movie.genre;
  document.getElementById('editYear').value = movie.year;
  document.getElementById('editDirector').value = movie.director;
  document.getElementById('editDuration').value = movie.duration;
  document.getElementById('editRating').value = movie.rating;

  currentStatus = movie.status;
  updateStatusButtons();
}

function updateStatusButtons() {
  statusButtons.forEach((btn) => {
    btn.classList.toggle('selected', btn.dataset.value === currentStatus);
  });
}

statusButtons.forEach((btn) => {
  btn.addEventListener('click', () => {
    currentStatus = btn.dataset.value;
    updateStatusButtons();
  });
});

loadMovie();

form.addEventListener('submit', async (e) => {
  e.preventDefault();

  const changes = {
    title: document.getElementById('editTitle').value.trim(),
    genre: document.getElementById('editGenre').value.trim(),
    year: parseInt(document.getElementById('editYear').value, 10),
    director: document.getElementById('editDirector').value.trim(),
    duration: document.getElementById('editDuration').value.trim(),
    rating: parseFloat(document.getElementById('editRating').value),
    status: currentStatus,
  };

  await Store.updateMovie(editMovieId, changes);
  window.location.href = `detail.html?id=${editMovieId}`;
});
