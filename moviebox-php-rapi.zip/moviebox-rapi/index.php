<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Moviebox - Home</title>
  <link rel="stylesheet" href="css/home.css">
</head>
<body>

  <div class="app-layout">

    <!-- ========================= -->
    <!-- SIDEBAR -->
    <!-- ========================= -->
    <aside class="sidebar">
      <div class="sidebar-avatar">
        <img src="image/avatar.png" alt="Moviebox">
      </div>

      <nav class="sidebar-nav">
        <button class="sidebar-btn add-movie" id="addMovieBtn">+ Add movie</button>
        <a class="sidebar-btn" href="profile.html">Reviews</a>
        <a class="sidebar-btn" href="watching-status.html">Watching Status</a>
      </nav>

      <div class="sidebar-spacer"></div>
      <img src="image/Logo.png" alt="Moviebox" class="sidebar-logo">
    </aside>

    <!-- ========================= -->
    <!-- MAIN CONTENT -->
    <!-- ========================= -->
    <main class="main-content">

      <!-- Topbar: tab navigasi + search -->
      <div class="topbar">
        <div class="topbar-tabs">
          <a href="index.php" class="active">Home</a>
          <a href="mylist.html">My list</a>
        </div>

        <div class="topbar-search">
          <div class="search-box">
            <svg viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27a6.5 6.5 0 1 0-.7.7l.27.28v.79l5 5L20.5 19l-5-5zm-6 0a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9z"/></svg>
            <input type="text" placeholder="Search">
          </div>
          <button class="sort-btn" title="Sort">
            <svg viewBox="0 0 24 24"><path d="M7 4l-4 4h3v8h2V8h3L7 4zm10 16l4-4h-3V8h-2v8h-3l4 4z"/></svg>
          </button>
        </div>
      </div>

      <!-- Grid film -->
      <div class="movie-grid" id="movieGrid">
        <!-- Kartu film di-generate lewat JS dari array MOVIES di script.js -->
      </div>

    </main>
  </div>

  <script src="store.js"></script>
  <script src="search-dropdown.js"></script>
  <script src="genre-filter.js"></script>
  <script src="index.js"></script>
</body>
</html>
