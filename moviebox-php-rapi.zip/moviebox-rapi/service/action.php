<?php
/* ============================================
   action.php — TAMBAH film baru ke database.
   Dipanggil dari halaman tambah.php (lewat store.js
   / addmovie.js) dengan body JSON.

   Kalau poster dikirim sebagai foto upload (data URL
   base64), file gambarnya disimpan ke folder uploads/
   dan yang disimpan ke DB cuma path-nya saja.
   ============================================ */

require 'database.php';
require 'helpers.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed, gunakan POST']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (($data['action'] ?? '') !== 'add') {
    echo json_encode(['error' => 'Unknown action']);
    exit;
}

$poster = savePosterIfUploaded($data['poster'] ?? '');

$stmt = $pdo->prepare(
    "INSERT INTO movies (id, title, year, genre, director, duration, rating, synopsis, status, saved, added_date, poster)
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?)"
);
$stmt->execute([
    $data['id'],
    $data['title'],
    $data['year'],
    $data['genre'],
    $data['director'],
    $data['duration'],
    $data['rating'],
    $data['synopsis'],
    $data['status'],
    !empty($data['saved']) ? 1 : 0,
    $data['addedDate'],
    $poster,
]);

echo json_encode(['success' => true]);
