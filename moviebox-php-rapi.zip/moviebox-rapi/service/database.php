<?php
/* ============================================
   database.php — satu-satunya tempat konfigurasi koneksi
   ke database MySQL (via XAMPP).
   Semua file service/*.php akan require file ini.
   ============================================ */

// Kalau nama database/user/password XAMPP kamu beda, ubah di sini saja.
$DB_HOST = "localhost";
$DB_NAME = "moviebox_db";
$DB_USER = "root";
$DB_PASS = "";      // default XAMPP: kosong (tanpa password)

try {
    $pdo = new PDO(
        "mysql:host={$DB_HOST};dbname={$DB_NAME};charset=utf8mb4",
        $DB_USER,
        $DB_PASS
    );
    // Supaya error SQL langsung "melempar" exception yang bisa kita tangkap,
    // bukannya diam-diam gagal.
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    http_response_code(500);
    header("Content-Type: application/json");
    echo json_encode([
        "error" => "Koneksi database gagal. Pastikan Apache & MySQL sudah Start di XAMPP, dan database 'moviebox_db' sudah diimport.",
        "detail" => $e->getMessage(),
    ]);
    exit;
}
