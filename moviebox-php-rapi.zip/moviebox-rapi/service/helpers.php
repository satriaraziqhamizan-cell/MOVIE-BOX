<?php
/* ============================================
   helpers.php — fungsi bantuan yang dipakai bareng
   oleh beberapa file service/*.php (movies.php,
   action.php, update.php).
   ============================================ */

// Ubah 1 baris hasil query jadi tipe data yang benar
// (MySQL selalu balikin string, padahal di JS kita butuh number/boolean).
function formatMovie($m) {
    if (!$m) return null;
    $m['year']   = (int)$m['year'];
    $m['rating'] = (float)$m['rating'];
    $m['saved']  = (bool)$m['saved'];
    return $m;
}

// Kalau poster dikirim sebagai data URL base64 (hasil upload file di
// tambah.php / edit.php), simpan jadi file asli di folder uploads/ dan
// kembalikan string CSS "url('uploads/namafile.jpg')" untuk disimpan
// ke kolom `poster`. Kalau posternya bukan data URL (misal poster
// bawaan di image/posters/ atau gradient warna), biarkan apa adanya.
function savePosterIfUploaded($posterValue) {
    if (!$posterValue || strpos($posterValue, 'data:image') === false) {
        return $posterValue;
    }

    // Ambil bagian base64 dari format: url('data:image/jpeg;base64,xxxxx')
    if (!preg_match('/data:image\/([a-zA-Z0-9.+-]+);base64,([^\')]+)/', $posterValue, $match)) {
        return $posterValue;
    }

    $extension = strtolower($match[1]) === 'jpeg' ? 'jpg' : preg_replace('/[^a-z0-9]/', '', strtolower($match[1]));
    $binary    = base64_decode($match[2]);
    if ($binary === false) {
        return $posterValue;
    }

    $uploadDir = __DIR__ . '/../uploads/';
    if (!is_dir($uploadDir)) {
        mkdir($uploadDir, 0755, true);
    }

    $filename = 'poster-' . uniqid() . '.' . $extension;
    file_put_contents($uploadDir . $filename, $binary);

    return "url('uploads/{$filename}')";
}
