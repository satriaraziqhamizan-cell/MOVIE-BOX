<?php
/* ============================================
   hapus.php — HAPUS film dari database.
   Dipanggil dari detail.js (tombol Delete) dengan
   body JSON: { id }.
   ============================================ */

require 'database.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed, gunakan POST']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (($data['action'] ?? '') !== 'delete') {
    echo json_encode(['error' => 'Unknown action']);
    exit;
}

$id = $data['id'] ?? '';
$stmt = $pdo->prepare("DELETE FROM movies WHERE id = ?");
$stmt->execute([$id]);

echo json_encode(['success' => true]);
