<?php
/* ============================================
   reviews.php — API untuk data review/ulasan di
   halaman Profile. Sama pola-nya dengan movies.php.

   - GET  ?action=all  -> semua review
   - POST action=add   -> tambah review baru
   ============================================ */

require 'database.php';
header('Content-Type: application/json');

$method = $_SERVER['REQUEST_METHOD'];

function formatReview($r) {
    if (!$r) return null;
    $r['rating'] = (float)$r['rating'];
    $r['likes']  = (int)$r['likes'];
    return $r;
}

if ($method === 'GET') {
    $stmt = $pdo->query("SELECT * FROM reviews ORDER BY created_at DESC");
    $reviews = array_map('formatReview', $stmt->fetchAll(PDO::FETCH_ASSOC));
    echo json_encode($reviews);
    exit;
}

if ($method === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);
    $action = $data['action'] ?? '';

    if ($action === 'add') {
        $stmt = $pdo->prepare(
            "INSERT INTO reviews (id, movie_id, movie_title, rating, text, likes, time_ago, poster)
             VALUES (?,?,?,?,?,?,?,?)"
        );
        $stmt->execute([
            $data['id'],
            $data['movieId'],
            $data['movieTitle'],
            $data['rating'],
            $data['text'],
            $data['likes'] ?? 0,
            $data['timeAgo'] ?? 'just now',
            $data['poster'] ?? null,
        ]);
        echo json_encode(['success' => true]);
        exit;
    }

    echo json_encode(['error' => 'Unknown POST action']);
    exit;
}
