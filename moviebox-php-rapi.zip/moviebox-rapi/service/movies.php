<?php
/* ============================================
   movies.php — API baca data film (list & detail).
   Untuk aksi tambah/ubah/hapus, lihat file
   action.php, update.php, dan hapus.php.

   - GET ?action=all          -> semua film
   - GET ?action=get&id=xxx   -> 1 film
   ============================================ */

require 'database.php';
require 'helpers.php';
header('Content-Type: application/json');

$action = $_GET['action'] ?? 'all';

if ($action === 'all') {
    $stmt = $pdo->query("SELECT * FROM movies ORDER BY created_at DESC");
    $movies = array_map('formatMovie', $stmt->fetchAll(PDO::FETCH_ASSOC));
    echo json_encode($movies);
    exit;
}

if ($action === 'get') {
    $id = $_GET['id'] ?? '';
    $stmt = $pdo->prepare("SELECT * FROM movies WHERE id = ?");
    $stmt->execute([$id]);
    $movie = $stmt->fetch(PDO::FETCH_ASSOC);
    echo json_encode(formatMovie($movie));
    exit;
}

echo json_encode(['error' => 'Unknown GET action']);
