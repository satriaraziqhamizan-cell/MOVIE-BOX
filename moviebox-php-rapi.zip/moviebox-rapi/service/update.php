<?php
/* ============================================
   update.php — UBAH data film yang sudah ada.
   Dipanggil dari halaman edit.php (lewat store.js /
   editmovie.js) dengan body JSON: { id, changes }.
   ============================================ */

require 'database.php';
require 'helpers.php';
header('Content-Type: application/json');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['error' => 'Method not allowed, gunakan POST']);
    exit;
}

$data = json_decode(file_get_contents('php://input'), true);

if (($data['action'] ?? '') !== 'update') {
    echo json_encode(['error' => 'Unknown action']);
    exit;
}

$id      = $data['id'] ?? '';
$changes = $data['changes'] ?? [];

// Whitelist kolom yang boleh diupdate, supaya aman dari input aneh-aneh.
$allowedColumns = ['title', 'genre', 'year', 'director', 'duration', 'rating', 'synopsis', 'status', 'saved', 'poster'];

$setParts = [];
$values = [];
foreach ($changes as $key => $value) {
    if (!in_array($key, $allowedColumns, true)) {
        continue;
    }
    if ($key === 'saved') {
        $value = !empty($value) ? 1 : 0;
    }
    if ($key === 'poster') {
        $value = savePosterIfUploaded($value);
    }
    $setParts[] = "$key = ?";
    $values[] = $value;
}

if (!empty($setParts)) {
    $values[] = $id;
    $sql = "UPDATE movies SET " . implode(', ', $setParts) . " WHERE id = ?";
    $pdo->prepare($sql)->execute($values);
}

echo json_encode(['success' => true]);
