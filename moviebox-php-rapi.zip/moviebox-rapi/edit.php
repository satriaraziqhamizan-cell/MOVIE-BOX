<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Moviebox - Edit Film</title>
  <link rel="stylesheet" href="css/home.css">
  <style>
    /* Style tambahan khusus edit film, mengikuti mockup (kartu gelap, input outline) */
    .edit-card {
      background: rgba(0,0,0,0.35);
      border: 1px solid rgba(255,255,255,0.1);
      border-radius: 14px;
      padding: 34px;
      display: flex;
      gap: 40px;
      max-width: 1000px;
      flex-wrap: wrap;
    }
    .edit-poster-col { width: 260px; flex-shrink: 0; }
    .edit-poster-col img, .edit-poster-col .poster-box {
      width: 100%;
      aspect-ratio: 2/3;
      border-radius: 8px;
      background-size: cover;
      background-position: center;
    }
    .edit-poster-col .label { font-size: 0.75rem; letter-spacing: 0.06em; text-transform: uppercase; color: rgba(255,255,255,0.55); margin-bottom: 10px; }
    .edit-fields-col { flex: 1; min-width: 280px; }
    .edit-fields-col .label { font-size: 0.75rem; letter-spacing: 0.06em; text-transform: uppercase; color: rgba(255,255,255,0.55); margin-bottom: 8px; }
    .edit-fields-col input {
      width: 100%;
      background: transparent;
      border: 1px solid rgba(255,255,255,0.3);
      border-radius: 6px;
      padding: 12px 14px;
      color: #fff;
      font-size: 0.95rem;
      outline: none;
      margin-bottom: 20px;
    }
    .edit-fields-col input:focus { border-color: #f2c94c; }
    .edit-field-row { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
    .edit-status-label { font-size: 0.75rem; letter-spacing: 0.06em; text-transform: uppercase; color: rgba(255,255,255,0.55); margin-bottom: 12px; }
    .edit-actions { display: flex; justify-content: flex-end; gap: 14px; margin-top: 20px; width: 100%; }
    .btn-batal { background: transparent; border: 1px solid #f2c94c; color: #f2c94c; padding: 11px 26px; border-radius: 8px; font-weight: 700; cursor: pointer; text-decoration: none; display: inline-flex; align-items: center; }
    .btn-update { background: #f2c94c; border: none; color: #1a1a1a; padding: 11px 30px; border-radius: 8px; font-weight: 800; cursor: pointer; }
    .btn-update:hover { filter: brightness(1.05); }
  </style>
</head>
<body>

  <div class="app-layout">

    <aside class="sidebar">
      <div class="sidebar-avatar">
        <img src="image/avatar.png" alt="Moviebox">
      </div>
      <nav class="sidebar-nav">
        <a class="sidebar-btn add-movie" href="tambah.php">+ Add movie</a>
        <a class="sidebar-btn" href="profile.html">Reviews</a>
        <a class="sidebar-btn" href="watching-status.html">Watching Status</a>
      </nav>
      <div class="sidebar-spacer"></div>
      <img src="image/Logo.png" alt="Moviebox" class="sidebar-logo">
    </aside>

    <main class="main-content">
      <div class="topbar">
        <div class="topbar-tabs">
          <a href="index.php">Home</a>
          <a href="mylist.html">My list</a>
        </div>
        <div class="topbar-search">
          <div class="search-box">
            <svg viewBox="0 0 24 24"><path d="M15.5 14h-.79l-.28-.27a6.5 6.5 0 1 0-.7.7l.27.28v.79l5 5L20.5 19l-5-5zm-6 0a4.5 4.5 0 1 1 0-9 4.5 4.5 0 0 1 0 9z"/></svg>
            <input type="text" placeholder="Search">
          </div>
          <button class="sort-btn" title="Sort">
            <svg viewBox="0 0 24 24"><path d="M7 4l-4 4h3v8h2V8h3L7 4zm10 16l4-4h-3V8h-2v8h-3l4 4z"/></svg>
          </button>
        </div>
      </div>

      <div class="page-heading">
        <h1>Edit Film</h1>
        <p>Update the metadata and status for your saved movie.</p>
      </div>

      <form id="editMovieForm" class="edit-card">
        <div class="edit-poster-col">
          <div class="label">Poster</div>
          <div class="poster-box" id="editPosterBox"></div>
        </div>

        <div class="edit-fields-col">
          <div class="label">Judul Film</div>
          <input type="text" id="editTitle" required>

          <div class="edit-field-row">
            <div>
              <div class="label">Genre</div>
              <input type="text" id="editGenre" required>
            </div>
            <div>
              <div class="label">Tahun</div>
              <input type="number" id="editYear" required>
            </div>
          </div>

          <div class="label">Sutradara</div>
          <input type="text" id="editDirector" required>

          <div class="edit-field-row">
            <div>
              <div class="label">Durasi</div>
              <input type="text" id="editDuration" required>
            </div>
            <div>
              <div class="label">Rating</div>
              <input type="number" id="editRating" min="0" max="10" step="0.1" required>
            </div>
          </div>

          <div class="edit-status-label">Status Tontonan</div>
          <div class="pill-choice-row" id="editStatusRow" style="margin-bottom: 10px;">
            <button type="button" class="pill-choice" data-value="want">Belum Ditonton</button>
            <button type="button" class="pill-choice" data-value="watched">Sedang Ditonton</button>
          </div>

          <div class="edit-actions">
            <a href="index.php" class="btn-batal">Batal</a>
            <button type="submit" class="btn-update">Update</button>
          </div>
        </div>
      </form>

    </main>
  </div>

  <script src="store.js"></script>
  <script src="search-dropdown.js"></script>
  <script src="edit.js"></script>
</body>
</html>
