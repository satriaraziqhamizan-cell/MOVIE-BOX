// ============================================
// MY LIST - render grid film tersimpan dari Store (API/DB)
// (getFilteredMovies & renderMyList sekarang async)
// ============================================

const mylistGrid = document.getElementById('mylistGrid');
const listCount = document.getElementById('listCount');
const searchInput = document.querySelector('.search-box input');
let watchedFilterActive = true;

function cardHTML(movie) {
  return `
    <div class="mylist-poster" style="background-image:${movie.poster};"></div>
    <div class="mylist-info">
      <h3>${movie.title}</h3>
      <p>${movie.year} • ${movie.genre}</p>
    </div>
  `;
}

async function getFilteredMovies() {
  let movies = (await Store.getAllMovies()).filter((m) => m.saved);

  if (watchedFilterActive) {
    movies = movies.filter((m) => m.status === 'watched');
  }

  const keyword = searchInput ? searchInput.value.toLowerCase() : '';
  if (keyword.trim()) {
    movies = movies.filter((m) => m.title.toLowerCase().includes(keyword));
  }

  if (typeof GenreFilter !== 'undefined') {
    movies = GenreFilter.apply(movies);
  }

  return movies;
}

async function renderMyList() {
  const movies = await getFilteredMovies();

  mylistGrid.innerHTML = '';

  if (movies.length === 0) {
    mylistGrid.innerHTML = `<p class="empty-state">Tidak ada film yang cocok dengan filter ini.</p>`;
  } else {
    movies.forEach((movie) => {
      const card = document.createElement('a');
      card.className = 'mylist-card';
      card.href = `detail.html?id=${movie.id}`;
      card.innerHTML = cardHTML(movie);
      mylistGrid.appendChild(card);
    });
  }

  const totalSaved = (await Store.getAllMovies()).filter((m) => m.saved).length;
  if (listCount) {
    listCount.textContent = `Your curated library of ${totalSaved} saved titles.`;
  }
}

renderMyList();

// Tombol hapus filter "Watched"
const removeFilter = document.getElementById('removeFilter');
const clearFilters = document.getElementById('clearFilters');
const filterRow = document.querySelector('.filter-row');

function clearAllFilters() {
  watchedFilterActive = false;
  if (filterRow) filterRow.style.display = 'none';
  renderMyList();
}

if (removeFilter) removeFilter.addEventListener('click', clearAllFilters);
if (clearFilters) clearFilters.addEventListener('click', clearAllFilters);

// Search dalam My List
if (searchInput) {
  searchInput.addEventListener('input', () => {
    renderMyList();
  });
}

// Filter genre - panel dibuka lewat tombol panah (sort-btn) di topbar
if (typeof GenreFilter !== 'undefined') {
  GenreFilter.onChange(() => {
    renderMyList();
  });
}

// Tombol "+Add movie"
const addMovieBtn = document.getElementById('addMovieBtn');
if (addMovieBtn) {
  addMovieBtn.addEventListener('click', () => {
    window.location.href = 'tambah.php';
  });
}
