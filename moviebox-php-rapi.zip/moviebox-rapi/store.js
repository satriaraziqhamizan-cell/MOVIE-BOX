// ============================================
// STORE — dulu baca/tulis ke localStorage,
// SEKARANG baca/tulis ke database MySQL lewat
// file-file PHP di folder service/.
//
// Nama-nama fungsinya (getAllMovies, addMovie, dst)
// SENGAJA dibiarkan sama supaya halaman lain
// (index.js, detail.js, dll) hampir tidak berubah —
// bedanya cuma sekarang setiap fungsi jadi ASYNC
// (mengembalikan Promise) karena harus menunggu
// jawaban dari server (fetch), jadi tiap kali
// dipanggil, wajib pakai kata "await" di depannya
// dan fungsi pemanggilnya juga wajib "async".
//
// Alurnya:
//   halaman html --(fetch)--> file PHP di /api
//        --(PDO/SQL)--> tabel di MySQL (XAMPP)
// ============================================

const API_BASE = "service/";

async function apiGet(url) {
  const res = await fetch(url);
  return res.json();
}

async function apiPost(url, payload) {
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(payload),
  });
  return res.json();
}

const Store = {
  // ---------- MOVIES ----------
  async getAllMovies() {
    return apiGet(`${API_BASE}movies.php?action=all`);
  },

  async getMovieById(id) {
    return apiGet(`${API_BASE}movies.php?action=get&id=${encodeURIComponent(id)}`);
  },

  async addMovie(movie) {
    return apiPost(`${API_BASE}action.php`, { action: "add", ...movie });
  },

  async updateMovie(id, changes) {
    return apiPost(`${API_BASE}update.php`, { action: "update", id, changes });
  },

  async removeMovie(id) {
    return apiPost(`${API_BASE}hapus.php`, { action: "delete", id });
  },

  // ---------- REVIEWS ----------
  async getAllReviews() {
    return apiGet(`${API_BASE}reviews.php?action=all`);
  },

  async addReview(review) {
    return apiPost(`${API_BASE}reviews.php`, { action: "add", ...review });
  },

  // ---------- PROFILE ----------
  async getProfile() {
    return apiGet(`${API_BASE}profile.php`);
  },

  async saveProfile(profile) {
    return apiPost(`${API_BASE}profile.php`, { action: "save", ...profile });
  },

  // ---------- HELPERS ----------
  async makeIdFromTitle(title) {
    const base = title
      .toLowerCase()
      .trim()
      .replace(/[^a-z0-9]+/g, "-")
      .replace(/(^-|-$)/g, "");
    let id = base || "movie";

    const existingIds = (await this.getAllMovies()).map((m) => m.id);
    let suffix = 1;
    while (existingIds.includes(id)) {
      suffix += 1;
      id = `${base}-${suffix}`;
    }
    return id;
  },
};
